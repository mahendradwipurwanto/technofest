###################
What is Technofest
###################

A website for manage exhibition event on STIKI Malang, this site content include user upload for their work, and admin management event.

*******************
Release Information
*******************

This repo containt two release version, first release containt base code of project. And the last release containt the final version of the release

**************************
Changelog and New Features
**************************

You can see changelog and features on commit history

*******************
Server Requirements
*******************

PHP version 7.2 or newer is recommended.

It should work on Codeigniter 3.x as well, but we strongly advise you NOT to run
such old versions of Codeigniter, because of potential security and performance
issues, as well as missing features.

************
Further Development
************

This project is the last and final development. All further development DO NOT CONTAIN new features but ONLY to fix bug and improve system!

New features will all deploy on NESTIVENT.ORG

*******
License
*******

Please see the `license
agreement <https://github.com/mahendradwipurwanto/technofest/blob/master/license.txt>`_.

***************
Acknowledgement
***************

The Development team would like to thank NESTIVENT.ORG and STIKI Malang for its big contribution.
