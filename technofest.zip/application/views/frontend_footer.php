

		<!-- Footer
			============================================= -->
			<footer id="footer" class="dark" style="background: linear-gradient(to bottom, rgba(255,255,255,.1), rgba(255,255,255,.03)); border-top-color: #222">
				<div class="container">

				<div id="copyrights" class="bg-transparent pt-0">
					<div style="margin-top: 5%;">

						<div class="col-lg-8 bottommargin-sm clearfix" style="color:#888;">
							<!-- <img src="images/logo.png" alt="Canvas Logo" style="display: block;" height="100"> -->

							<a href="https://www.instagram.com/stiki.technofest/" target="_blank" class="social-icon si-small si-borderless si-colored si-rounded si-instagram">
								<i class="icon-instagram"></i>
								<i class="icon-instagram"></i>
							</a>

						</div>

						<div class="w-100 text-center text-md-left">
				      <!-- SUPPPORT THE DEVELOPER, PLEASE DO NOT REMOVE OR CHANGES THIS LINE -->
							Copyrights &copy; 2021 All Rights Reserved by STIKI 2021 supported by <a href="www.nestivent.org" target="_blank"> <i>Nestivent.org</i></a>.<br>
							<!-- END SUPPORT LINE -->
						</div>

					</div>
				</div><!-- #copyrights end -->
			</footer><!-- #footer end -->

		</div><!-- #wrapper end -->

	<!-- Go To Top
		============================================= -->
		<div id="gotoTop" class="icon-angle-up"></div>

	<!-- JavaScripts
		============================================= -->
		<script src="<?php echo base_url();?>assets/frontend/js/jquery.js"></script>
		<script src="<?php echo base_url();?>assets/frontend/js/plugins.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.lazyload/1.9.1/jquery.lazyload.min.js" integrity="sha512-jNDtFf7qgU0eH/+Z42FG4fw3w7DM/9zbgNPe3wfJlCylVDTT3IgKW5r92Vy9IHa6U50vyMz5gRByIu4YIXFtaQ==" crossorigin="anonymous"></script>
	<!-- Footer Scripts
		============================================= -->
		<script src="<?php echo base_url();?>assets/frontend/js/functions.js"></script>


</body>
</html>
